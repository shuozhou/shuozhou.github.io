%% Shuo Zhou, Sarah Erfani, James Bailey,
% "Online CP Decomposition for Sparse Tensors",
% (C) 2018 Shuo Zhou   
% Email: zhous@student.unimelb.edu.au

% To run the code, Tensor Toolbox is required.
% Brett W. Bader, Tamara G. Kolda and others. MATLAB Tensor Toolbox 
% Version 2.6, Available online. 
% URL: http://www.sandia.gov/~tgkolda/TensorToolbox/

%% Update stage of OnlineSCP
% input:  X_new, the new incoming data tensor
%         As, a cell array contains the previous *N-1* loading matrices
%             (apart from the last one for the time mode)
%         Q, U_N, complementray matrices
% ouputs: As, updated loading matrices
%         Q, U_N, updated complementray matrices
%         alpha, coefficient on time mode of X_new
%         mem, memory usage

function [ As, Q, U_N, alpha, mem] = onlineSCP_update( X_new, As, Q, U_N )
N = length(As)+1;
R = size(As{1},2);
dims = size(X_new);

if isempty(X_new.subs)
    alpha = zeros(dims(end), R);
    return
end

Q_tilde = Q;

% update mode N
alpha = zeros(dims(end), R);
Q_N = Q./U_N;
[deltaP_N, mttkrp_mem] = spmttkrp_mem(X_new, [As; alpha], N);
alpha = deltaP_N/Q_N;
U_N = U_N+alpha'*alpha;
Q = Q_N.*U_N;

% update mode 1 to N-1
for n=1:N-1
    A_tilde = As{n};
    AtA = As{n}'*As{n};
    Q_n_tilde = Q_tilde./AtA;
    Q_n = Q./AtA;
    [deltaP_n, mem_n] = spmttkrp_mem(X_new, [As; alpha], n);
    if mem_n > mttkrp_mem
        mttkrp_mem = mem_n;
    end
    As{n} = (As{n}*Q_n_tilde+deltaP_n)/Q_n;
    Q_tilde = Q_n_tilde.*(A_tilde'*As{n});
    Q = Q_n.*(As{n}'*As{n});
end
var_list = whos;
storage_overhead = sum([var_list(:).bytes]);
mem = storage_overhead + mttkrp_mem;
end

