%% Shuo Zhou, Sarah Erfani, James Bailey,
% "Online CP Decomposition for Sparse Tensors",
% (C) 2018 Shuo Zhou   
% Email: zhous@student.unimelb.edu.au

% To run the code, Tensor Toolbox is required.
% Brett W. Bader, Tamara G. Kolda and others. MATLAB Tensor Toolbox 
% Version 2.6, Available online. 
% URL: http://www.sandia.gov/~tgkolda/TensorToolbox/

%% This is a demo to compare OnlineSCP with classic ALS algorithms

clc;clear;close all;
% addpath(genpath('./tensor_toolbox_2.6'));
addpath(genpath('../'));

%% load data or create synthetic data
% load('ml.mat', 'X'); % MovieLens dataset
% dims = size(X);
% N = length(dims);
% tao = round(0.5 *dims(end)); % half data for initilaziation
% TT = dims(end)-tao;
% R = 5;
% steps = 100;
% minibatchSize = round(TT/steps);

rng(123); % code may run into problem when new data part is all zero
dims = [200, 200, 500];
N = length(dims);
tao = round(0.2 *dims(end));
TT = dims(end)-tao;
R = 5;
steps = 50;
minibatchSize = round(TT/steps);

As = arrayfun(@(x) full(sprand(x, R, 0.2)), dims, 'uni', 0);
X = sptensor(full(ktensor(As(:))));
% add noise
X(X.subs) = X.vals + 0.01*randn(size(X.vals));

density = nnz(X)/prod(dims)

%% initialization
% factorize initX and initiallize each algorithm
fprintf('====================================================\n');
fprintf('Initialziation\n');

idx = repmat({':'}, 1, N);
idx(end) = {1:tao};
initX = X(idx{:});
initOpt.printitn = 1;
initOpt.maxiters = 200;
initOpt.tol = 1e-8;
estInitX = cp_als(sptensor(initX), R, initOpt);
initAs = estInitX.U;
% absorb lambda into the last dimension
initAs{end} = initAs{end}*diag(estInitX.lambda);

% init batch 
batchAs = initAs;
batchOpt.printitn = 0;
batchOpt.maxiters = 1;

% init onlineSCP
[onlineSCP_Q, onlineSCP_AtA_N] = onlineSCP_init(initX, initAs, R);
onlineSCP_As = initAs(1:end-1);
onlineSCP_As_N = initAs{end};

%% adding new data
fprintf('====================================================\n');
fprintf('Adding new data\n');

fit = zeros(2, steps);
time = zeros(2, steps);
mem = zeros(2, steps);
k = 1;
for t=1:minibatchSize:TT
    fprintf('%dth steps\n', k);
    % get the incoming slice
    endTime = min(tao+t+minibatchSize-1, dims(end));
    idx(end) = {tao+t:endTime};
    x = X(idx{:});
    numOfSlice = endTime-tao-t+1;
    x = reshape(x, [dims(1:N-1), numOfSlice]);
    % get tensor X of current time
    idx(end) = {1:endTime};
    Xt = X(idx{:});
    
    % batch
    tic;
    batchAlpha = rand(numOfSlice,R);
    batchAs{end} = [batchAs{end}; batchAlpha];
    batchOpt.init = batchAs;
    [batchXt, batch_mem] = als_mem(Xt, R, batchOpt);
    batchAs = batchXt.U;
    batchAs{end} = batchAs{end}*diag(batchXt.lambda);
    runtime = toc;
    fit(1, k) = get_fit(Xt, ktensor(batchAs));
    time(1, k) = runtime;
    mem(1, k) = batch_mem;

    tic;
    [onlineSCP_As, onlineSCP_Q, onlineSCP_AtA_N, onlineSCP_Alpha, onlineSCP_mem] =...
        onlineSCP_update(x, onlineSCP_As, onlineSCP_Q, onlineSCP_AtA_N);
    onlineSCP_As_N(end+1:end+numOfSlice,:) = onlineSCP_Alpha;
    runtime = toc;
    tmp = [onlineSCP_As; onlineSCP_As_N];
    fit(2, k) = get_fit(Xt, ktensor(tmp));
    time(2, k) = runtime;
    mem(2, k) = onlineSCP_mem;
    
    k = k+1;
end

%% plot results
figure('Position', [500, 500, 1800, 500])

subplot(1,3,1);
hold on;
grid on;
plot(fit(1,:), 'r-^', 'MarkerSize', 10, 'LineWidth', 2);
plot(fit(2,:), 'k-', 'LineWidth', 4);
legend('ALS', 'OnlineCP');
xlabel('Time');
ylabel('Fitness');
set(gca, 'FontSize', 16);

subplot(1,3,2);
hold on;
grid on;
plot(time(1,:), 'r-^', 'MarkerSize', 10, 'LineWidth', 2);
plot(time(2,:), 'k-', 'LineWidth', 4);
legend('ALS', 'OnlineCP');
xlabel('Time');
ylabel('Running Time (in seconds)');
set(gca, 'FontSize', 16);

subplot(1,3,3);
hold on;
grid on;
mem = mem/1024;
plot(mem(1,:), 'r-^', 'MarkerSize', 10, 'LineWidth', 2);
plot(mem(2,:), 'k-', 'LineWidth', 4);
legend('ALS', 'OnlineCP');
xlabel('Time');
ylabel('Memory Usage (in KBs)');
set(gca, 'FontSize', 16);
