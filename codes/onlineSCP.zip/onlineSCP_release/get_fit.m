%% Shuo Zhou, Sarah Erfani, James Bailey,
% "Online CP Decomposition for Sparse Tensors",
% (C) 2018 Shuo Zhou   
% Email: zhous@student.unimelb.edu.au

%% calculate fitness
% input:  X, ground truth
%         P, approximation
% ouputs: fit, 1-||X-P||_F/||X||_F
function [ fit ] = get_fit( X, P )
    normX = norm(X);
    normresidual = real(sqrt( normX^2 + norm(P)^2 - 2 * innerprod(X,P)));
    fit = 1 - (normresidual / normX); %fraction explained by model
end

