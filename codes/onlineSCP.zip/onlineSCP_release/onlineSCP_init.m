%% Shuo Zhou, Sarah Erfani, James Bailey,
% "Online CP Decomposition for Sparse Tensors",
% (C) 2018 Shuo Zhou   
% Email: zhous@student.unimelb.edu.au

% To run the code, Tensor Toolbox is required.
% Brett W. Bader, Tamara G. Kolda and others. MATLAB Tensor Toolbox 
% Version 2.6, Available online. 
% URL: http://www.sandia.gov/~tgkolda/TensorToolbox/

%% Update stage of OnlineSCP
% input:  initX, the sptensor for initialization
%         As, the loading matrices of the CP decomposition of initX
%         R, decomposition rank
% ouputs: Q, complementary matrix as 
%            \Circledast_{i=1}^{N} {\mathbf{A}^{(i)}}^{\top}\mathbf{A}^{(i)}
%         U_N, complementary matrix for time mode as
%            {\mathbf{A}^{(N)}}^{\top}\mathbf{A}^{(N)}
function [ Q, U_N ] = onlineSCP_init( initX, As, R )
% if As is not given, calculate the CP decomposition of the initial data by
% cp_als
if ~exist('As')
    estInitX = cp_als(tensor(initX), R, 'tol', 1e-8);
    As = estInitX.U;
    % absorb lambda into the last dimension
    As{end} = As{end}*diag(estInitX.lambda);
end

dims = size(initX);
N = length(dims);

Q = ones(R,R);
for n=1:N-1
    Q = Q.*(As{n}'*As{n});
end
U_N = As{N}'*As{N};
Q = Q.*U_N;
end

