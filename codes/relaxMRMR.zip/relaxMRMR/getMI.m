% Nguyen Xuan Vinh, Shuo Zhou, Jeffrey Chan, James Bailey, "Can High-Order Dependencies Improve Mutual Information based Feature Selection?",
% (C) 2015 Shuo Zhou   
% Email: zhous@student.unimelb.edu.au, zhous.se@gmail.com
% getMI generate the pairwise mutual information between feature Xm and Xj
% I(Xm; Xj)

function MI = getMI(a)
[n, dim] = size(a);
for i = 1:dim
    if mod(i, 100) == 0
        fprintf('filling MI table %dth row\n', i);
    end
    for j = 1:dim
        MI(i,j) = mi(a(:,i), a(:,j));
    end
end
end
