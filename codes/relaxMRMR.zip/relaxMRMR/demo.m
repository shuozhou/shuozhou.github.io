% Nguyen Xuan Vinh, Shuo Zhou, Jeffrey Chan, James Bailey, "Can High-Order 
% Dependencies Improve Mutual Information based Feature Selection?",
% (C) 2015 Shuo Zhou   
% Email: zhous@student.unimelb.edu.au, zhous.se@gmail.com
% Demo Script

clear;clc;
addpath(genpath('MIToolbox'));
load('demo_data.mat');

% normalization
normData=normalizeMax(data); 
% discretize data
disData = discretizeData(normData,5);

% mutual information between features
% I(Xm; Xj)
MI = getMI(disData);
% mutual information between feature and class label
% I(Xm; C)
MI_C = getMI_C(disData, label);
% conditional mutual information between features given class
% I(Xm; Xj | C)
CMI_C = getCMI_C(disData, label);

maxFeature = 20;
form = 2;
relaxFS = relaxMRMR(disData, MI, MI_C, CMI_C, form, maxFeature);

fprintf('\nRelaxMRMR, done!\n')
