% Nguyen Xuan Vinh, Shuo Zhou, Jeffrey Chan, James Bailey, "Can High-Order Dependencies Improve Mutual Information based Feature Selection?",
% (C) 2015 Shuo Zhou   
% Email: zhous@student.unimelb.edu.au, zhous.se@gmail.com
% getCMI_C generate pairwise conditional mutual information between feature Xm and Xj,
% given class C
% I(Xm; Xj | C)

function CMI_C = getCMI_C(a, C)
[n dim] = size(a);
for i = 1:dim
    if mod(i, 100) == 0
        fprintf('filling CMI_C table %dth row\n', i);    
    end
    for j = 1:dim
        CMI_C(i,j) = cmi(a(:,i), a(:,j), C);
    end
end
end