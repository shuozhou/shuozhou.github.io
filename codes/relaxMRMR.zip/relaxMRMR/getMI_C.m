% Nguyen Xuan Vinh, Shuo Zhou, Jeffrey Chan, James Bailey, "Can High-Order Dependencies Improve Mutual Information based Feature Selection?",
% (C) 2015 Shuo Zhou   
% Email: zhous@student.unimelb.edu.au, zhous.se@gmail.com
% getMI_C generate mutual information between feature Xm and the class
% label C
% I(Xm; C)

function MI_C = getMI_C(a, C)
[n, dim] = size(a);
for i = 1:dim
    if mod(i, 100) == 0    
        fprintf('filling MI_C table %dth row\n', i);
    end
    MI_C(i) = mi(a(:,i), C);
end
end