% Nguyen Xuan Vinh, Shuo Zhou, Jeffrey Chan, James Bailey, "Can High-Order 
% Dependencies Improve Mutual Information based Feature Selection?",
% (C) 2015 Shuo Zhou   
% Email: zhous@student.unimelb.edu.au, zhous.se@gmail.com
% relaxMRMR select feature based on relaxed MRMR 
% form0 un-normalized
% argmax{I(Xm;C)-sum(I(Xm;Xj)-|S|*I(Xm;Xj|C)+sum(I(Xm;Xi|Xj))/|S|}
% form1 only normalize the class conditional term
% argmax{I(Xm;C)-sum(I(Xm;Xj)-I(Xm;Xj|C)+sum(I(Xm;Xi|Xj)))/|S|}
% form2 bring every term into same scale
% argmax{I(Xm;C)-sum(I(Xm;Xj)-I(Xm;Xj|C)+sum(I(Xm;Xi|Xj))/(|S|-1))/|S|}

function [relaxMRMRFS, timeStats, CMI_S] = relaxMRMR(a, MI, ...
    MI_C, CMI_C, form, maxFeature)
%% input
% a, the #instance*#feature data
% MI, mutual information between features, I(Xm; Xj)
% MI_C, mutual information between feature and class label, I(Xm; C)
% CMI_C, conditional mutual information between features given class, I(Xm; Xj | C)
% form, the normalization form
% maxFeature, the maximum number of selected features

%% output
% relaxMRMRFS, selected best feature set
% timeStats, time consumption for selecting each feature
% CMI_S, conditional mutual information between features given selected feature,
%        sum(I(Xm; Xi | Xj))

%% preparation
[n, dim] = size(a);
if nargin < 5
    form = 2;
    maxFeature = dim;
elseif nargin < 6
    maxFeature = dim;
end

% conditional mutual information between features given selected feature
% sum(I(Xm; Xi | Xj))
CMI_S = zeros(dim, dim);

fprintf('relaxMRMR started...\n');

% prealloc output
selected = zeros(1, dim);
relaxMRMRFS = zeros(1, maxFeature);
% time consumption for selecting current feature
timeStats = zeros(1, maxFeature);

%% select first feature as the one with max MI with C
fprintf('relaxMRMR: select the first feature\n');
tic;
max_MI = 0;
firstFeature = 1;
for i = 1:dim
    if MI_C(i) > max_MI
        max_MI = MI_C(i);
        firstFeature = i;
    end
end
relaxMRMRFS(1) = firstFeature;
selected(firstFeature) = 1;
timeStats(1) = toc();
fprintf('The first feature: %d with MI: %f\n', firstFeature, max_MI);

%% forward selection
fprintf('Forward selection...\n');
for j = 2:maxFeature
    fprintf('relaxMRMR: select the %dth feature\n', j);
    tic;
    maxInc = -inf;
    bestFeature = 0;
    for m = 1:dim
        if selected(m) 
           continue;
        end
        
        % relevance
        rel = MI_C(m);
        % redundancy
        red = 0;

        S = relaxMRMRFS(1:j-1);
        % un-normalized, orignial form
        if form == 0
            red = sum(MI(m,S)-(j-1)*CMI_C(m,S)+CMI_S(m,S))/(j-1);
        % only normalize the class conditional mutual information
        elseif form == 1
            red = sum(MI(m,S)-CMI_C(m,S)+CMI_S(m,S))/(j-1);
        % bring every term to same scale
        elseif form == 2
            if j == 2
                red = sum(MI(m,S)-CMI_C(m,S))/(j-1);
            else
                red = sum(MI(m,S)-CMI_C(m, S)+CMI_S(m,S)/(j-2))/(j-1);
            end        
        end
        
        % increasment
        inc = rel - red;  
%         fprintf('max_inc: %f, bestFeature: %f\n', maxInc, bestFeature);
        if inc > maxInc
           maxInc = inc;
           bestFeature = m;
        end
%         fprintf('m: %f max_inc: %f, bestFeature: %f\n', m, maxInc, bestFeature);

    end
    
    relaxMRMRFS(j) = bestFeature;
    selected(bestFeature) = 1;
    
    % update the CMI_S
    CMI_S = updateCMI_S(CMI_S, a, relaxMRMRFS, bestFeature);

    timeStats(j) = toc();
    
    fprintf('the %dth feature: %d with inc: %f\n', j, bestFeature, maxInc);
end
end
