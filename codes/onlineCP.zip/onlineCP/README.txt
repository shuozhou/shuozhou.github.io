Shuo Zhou, Xuan Vinh Nguyen, James Bailey, Yunzhe Jia, Ian Davidson,
"Accelerating Online CP Decompositions for Higher Order Tensors", KDD'16
(C) 2016 Shuo Zhou
Email: zhous@student.unimelb.edu.au

It's free for research and academic purpose.
For usages other than those, please contact me before use.

The code relies on Tensor Toolbox[1] and you can download it from the URL below.
[1] Brett W. Bader, Tamara G. Kolda and others. MATLAB Tensor Toolbox
Version 2.6, Available online, February 2015.
URL: http://www.sandia.gov/~tgkolda/TensorToolbox/
