%% Shuo Zhou, Sarah Erfani, and James Bailey,
% "SCED: a general framework for sparse tensor decompositions with
%  constraints and elementwise dynamic learning",
% (C) 2017 Shuo Zhou
% Email: zhous@student.unimelb.edu.au

% To run the code, Tensor Toolbox is required.
% Brett W. Bader, Tamara G. Kolda and others. MATLAB Tensor Toolbox
% Version 2.6, Available online, February 2015.
% URL: http://www.sandia.gov/~tgkolda/TensorToolbox/

%% add one new element to existing data and the sparse index
function [ X, sparseIdx ] = addone( X, newVal, newSub, sparseIdx )
N = length(newSub);

X(newSub) = newVal;

for n=1:N
    sparseIdx{n}{newSub(n)}(end+1,:) = nnz(X);
end
end

