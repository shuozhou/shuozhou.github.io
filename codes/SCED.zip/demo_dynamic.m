%% Shuo Zhou, Sarah Erfani, and James Bailey,
% "SCED: a general framework for sparse tensor decompositions with
%  constraints and elementwise dynamic learning",
% (C) 2017 Shuo Zhou
% Email: zhous@student.unimelb.edu.au

% To run the code, Tensor Toolbox is required.
% Brett W. Bader, Tamara G. Kolda and others. MATLAB Tensor Toolbox
% Version 2.6, Available online, February 2015.
% URL: http://www.sandia.gov/~tgkolda/TensorToolbox/

%% demo for dynamic case
clc;clear;
close all;

addpath(genpath('.'));

% load('data/syth_t_200.mat');
% load('data/syth_m_200.mat');
load('data/syth_i_200.mat');

% input tensor
X = data.X;
% ground truth
S = data.S;

R = 20;

dims = size(X);
N = length(dims);
density = nnz(X)/prod(dims);

opt.maxiters = 50;
opt.eval = S;
opt.nonneg = 0;
opt.lambda = 0;

sced_t_opt = opt;
sced_t_opt.alpha = 1;

sced_m_opt = opt;
sced_m_opt.alpha = 0;

sced_i_opt = opt;
sced_i_opt.alpha = density;

K = 2; % number of repetitions
for k = 1:K
    %% divede data into 90% train and 10% test
    nonzeros = round(.9*nnz(X));
    idx = randsample(nnz(X),nonzeros);
    Xtrain = sptensor(X.subs(idx,:),X.vals(idx),dims);
    Xtest = X;
    Xtest(Xtrain.subs) = 0;
    sparse_idx = precompute_sparse_idx(Xtrain);
    
    %% offline learning step for true observations case
    % init with Xtrain
    sced_t_opt.sparse_idx = sparse_idx;
    sced_t_initX = SCED(Xtrain,R,sced_t_opt);
    sced_t_fit_init(k) = get_fit(sced_t_initX, S);
    sced_t_opt.As = sced_t_initX.U;
    sced_t_opt.As{end} = sced_t_opt.As{end}*diag(sced_t_initX.lambda);
    sced_t_opt.AtA = zeros(R,R,N);
    for n = 1:N
        sced_t_opt.AtA(:,:,n) = sced_t_opt.As{n}'*sced_t_opt.As{n};
    end    
    sced_t_opt.maxiters = 1;
    sced_t_Xtrain = sced_t_initX;
    
    %% offline learning step for missing values case
    % init with Xtrain
    sced_m_opt.sparse_idx = sparse_idx;
    sced_m_initX = SCED(Xtrain,R,sced_m_opt);
    sced_m_fit_init(k) = get_fit(sced_m_initX, S);
    sced_m_opt.As = sced_m_initX.U;
    sced_m_opt.As{end} = sced_m_opt.As{end}*diag(sced_m_initX.lambda);
    sced_m_opt.AtA = zeros(R,R,N);  
    sced_m_opt.maxiters = 1;
    tmp = ones(nnz(Xtrain),R);
    for n=1:N
        tmp = tmp.*sced_m_opt.As{n}(Xtrain.subs(:,n),:);
    end
    sced_m_opt.X_hatVals = sum(tmp,2);
    sced_m_Xtrain = sced_m_initX;

    %% offline learning step for implicit information
    % init with Xtrain
    sced_i_opt.sparse_idx = sparse_idx;
    sced_i_initX = SCED(Xtrain,R,sced_i_opt);
    sced_i_fit_init(k) = get_fit(sced_i_initX, S);
    sced_i_opt.As = sced_i_initX.U;
    sced_i_opt.As{end} = sced_i_opt.As{end}*diag(sced_i_initX.lambda);
    sced_i_opt.AtA = zeros(R,R,N);
    for n = 1:N
        sced_i_opt.AtA(:,:,n) = sced_i_opt.As{n}'*sced_i_opt.As{n};
    end    
    sced_i_opt.maxiters = 1;
    tmp = ones(nnz(Xtrain),R);
    for n=1:N
        tmp = tmp.*sced_i_opt.As{n}(Xtrain.subs(:,n),:);
    end
    sced_i_opt.X_hatVals = sum(tmp,2);
    sced_i_Xtrain = sced_i_initX;
   
    %% online learning phase
    count = 0;
    for i=randperm(nnz(Xtest))
        count = count+1;
        newVal = Xtest.vals(i);
        newSub = Xtest.subs(i,:);
        
        % add a new cell to Xtrain
        [ Xtrain, sparse_idx ] = addone( Xtrain, newVal, newSub, sparse_idx );
        
        % learn one new element by sced_t
        sced_t_opt.sparse_idx = sparse_idx;
        [ sced_t_Xtrain, sced_t_opt, sced_t_time(k,count) ] = updateone(...
            Xtrain, R, sced_t_opt, newSub );
        
        % learn one new element by sced_m
        sced_m_opt.X_hatVals(end+1) = sced_m_Xtrain(newSub);         
        sced_m_opt.sparse_idx = sparse_idx;
        [ sced_m_Xtrain, sced_m_opt, sced_m_time(k,count) ] = updateone(...
            Xtrain, R, sced_m_opt, newSub );

        % learn one new element by sced_i
        sced_i_opt.X_hatVals(end+1) = sced_i_Xtrain(newSub);         
        sced_i_opt.sparse_idx = sparse_idx;
        [ sced_i_Xtrain, sced_i_opt, sced_i_time(k,count) ] = updateone(...
            Xtrain, R, sced_i_opt, newSub );
        
        step = 100;
        if mod(count,step)==0
            sced_t_fit(k,round(count/step)) = get_fit(sced_t_Xtrain,S);      
            sced_m_fit(k,round(count/step)) = get_fit(sced_m_Xtrain,S);
            sced_i_fit(k,round(count/step)) = get_fit(sced_i_Xtrain,S);
            fprintf('round: %d rate : %.2f%%\n', k, 100*count/nnz(Xtest))
        end
    end
    
    %% decompose the final tensor with batch method
    sced_t_opt.As = sced_t_initX.U;
    sced_t_opt.As{end} = sced_t_opt.As{end}*diag(sced_t_initX.lambda);
    sced_t_opt.maxiters = 50;
    sced_t_finalX = SCED(Xtrain,R,sced_t_opt);
    sced_t_fit_final(k) = get_fit(sced_t_finalX, S);

    sced_m_opt.As = sced_m_initX.U;
    sced_m_opt.As{end} = sced_m_opt.As{end}*diag(sced_m_initX.lambda);
    sced_m_opt.maxiters = 50;
    sced_m_finalX = SCED(Xtrain,R,sced_m_opt);
    sced_m_fit_final(k) = get_fit(sced_m_finalX, S);
    
    sced_i_opt.As = sced_i_initX.U;
    sced_i_opt.As{end} = sced_i_opt.As{end}*diag(sced_i_initX.lambda);
    sced_i_opt.maxiters = 50;
    sced_i_finalX = SCED(Xtrain,R,sced_i_opt);
    sced_i_fit_final(k) = get_fit(sced_i_finalX, S);
end

%% plot results
x = [1:100:nnz(Xtest)];

figure('position', [0, 0, 500, 400])
hold on;
p1 = plot(1,mean(sced_t_fit_init),'kp','MarkerSize',15,'MarkerFaceColor','k');
plot(nnz(Xtest),mean(sced_t_fit_final),'kp','MarkerSize',15,'MarkerFaceColor','k')
p2 = plot(x,mean(sced_t_fit, 1),'r-o','LineWidth',2,'MarkerSize',10);
legend([p1,p2],{'Batch','SCED-t'},'Location','southwest');
xlabel('Number of new entries');
ylabel({'Fitness'});
grid on;
set(gca,'FontSize',14);

figure('position', [600, 0, 500, 400])
hold on;
p1 = plot(1,mean(sced_m_fit_init),'kp','MarkerSize',15,'MarkerFaceColor','k');
plot(nnz(Xtest),mean(sced_m_fit_final),'kp','MarkerSize',15,'MarkerFaceColor','k')
p2 = plot(x,mean(sced_m_fit, 1),'b-+','LineWidth',2,'MarkerSize',10);
legend([p1,p2],{'Batch','SCED-m'},'Location','southwest');
xlabel('Number of new entries');
ylabel({'Fitness'});
grid on;
set(gca,'FontSize',14);

figure('position', [1200, 0, 500, 400])
hold on;
p1 = plot(1,mean(sced_i_fit_init),'kp','MarkerSize',15,'MarkerFaceColor','k');
plot(nnz(Xtest),mean(sced_i_fit_final),'kp','MarkerSize',15,'MarkerFaceColor','k')
p2 = plot(x,mean(sced_i_fit, 1),'k','LineWidth',2,'MarkerSize',10);
legend([p1,p2],{'Batch','SCED-i'},'Location','southwest');
xlabel('Number of new entries');
ylabel({'Fitness'});
grid on;
set(gca,'FontSize',14);