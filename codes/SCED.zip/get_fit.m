%% Shuo Zhou, Sarah Erfani, and James Bailey,
% "SCED: a general framework for sparse tensor decompositions with
%  constraints and elementwise dynamic learning",
% (C) 2017 Shuo Zhou
% Email: zhous@student.unimelb.edu.au

% To run the code, Tensor Toolbox is required.
% Brett W. Bader, Tamara G. Kolda and others. MATLAB Tensor Toolbox
% Version 2.6, Available online, February 2015.
% URL: http://www.sandia.gov/~tgkolda/TensorToolbox/

%% get effectiveness measurment
% input:  X, the ktensor formed by CP decomposition
%         S, the evaluation set, can be a ktensor that stands for the
%         ground truth decomposition, or a sptensor contains testing data
function [ fit ] = get_fit( X, S )
if isa(S, 'ktensor')
    normresidual = sqrt( norm(S)^2 + norm(X)^2 - 2 * innerprod(S,X) );
    fit = real(1 - (normresidual / norm(S)));
elseif isa(S, 'sptensor')    
    W = (S~=0);
    Z = W.*X;
    fit = sqrt((norm(Z)^2+norm(S)^2-2*innerprod(Z,S))/nnz(S));
else
    fprintf('wrong solution type\n');
end

