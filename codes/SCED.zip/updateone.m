function [ X_hat, opt, time ] = updateone( X, R, opt, new_idx)
if opt.alpha == 0
    [ X_hat, opt, time ] = updateone_m( X, R, opt, new_idx);
elseif opt.alpha == 1
    [ X_hat, opt, time] = updateone_t( X, R, opt, new_idx );
else
    [ X_hat, opt, time ] = updateone_i( X, R, opt, new_idx );
end

end

function [ X_hat, opt, time ] = updateone_i( X, R, opt, new_idx )
Xsubs = X.subs;
Xvals = X.vals;
As = opt.As;
alpha = opt.alpha;
N = ndims(X);
% main loop
time = [];
for iter=1:opt.maxiters
    tic
    for n=1:N
        Q_n = prod(opt.AtA(:,:,[1:n-1,n+1:N]),3);
        A = As{n};
        i = new_idx(n);
        nz_ni = opt.sparse_idx{n}{i};
        nnz_ni = length(nz_ni);
        if nnz_ni ~= 0     
            subs_ni = Xsubs(nz_ni,:);
            B = ones(nnz_ni,R);
            for nn = [1:n-1,n+1:N]
                B = B.*As{nn}(subs_ni(:,nn),:);
            end
            x = Xvals(nz_ni)';
            a = A(i,:);
            x_hat = opt.X_hatVals(nz_ni)';
            for r=1:R
                br = B(:,r);
                qr = Q_n(:,r);
                qrr = Q_n(r,r);
                xr_hat = (x_hat-a(r)*br');
                a(r) = ((x-(1-alpha)*xr_hat)*br...
                    -alpha*(a*qr-a(r)*qrr))/...
                    ((1-alpha)*(br'*br)+alpha*qrr+opt.lambda);
                x_hat = xr_hat+a(r)*br';
            end
            opt.X_hatVals(nz_ni) = x_hat';
            A(i,:) = a;                
        else
            A(i,:) = zeros(1,R);
        end
        As{n} = A;
        opt.AtA(:,:,n) = As{n}'*As{n};
    end
    time(end+1) = toc;
    opt.As = As;
    X_hat = ktensor(As);
%     fit(end+1) = getFit(X_hat,S);
end
end

function [ X_hat, opt, time ] = updateone_m( X, R, opt, new_idx )
Xsubs = X.subs;
Xvals = X.vals;
As = opt.As;
N = ndims(X);

% main loop
time = [];
% fit = [];
for iter=1:opt.maxiters
    tic
    for n=1:N
        A = As{n};
        i = new_idx(n);
        nz_ni = opt.sparse_idx{n}{i};
        nnz_ni = length(nz_ni);
        if nnz_ni ~= 0     
            subs_ni = Xsubs(nz_ni,:);
            B = ones(nnz_ni,R);
            for nn = [1:n-1,n+1:N]
                B = B.*As{nn}(subs_ni(:,nn),:);
            end
            x = Xvals(nz_ni)';
            a = A(i,:);
            x_hat = opt.X_hatVals(nz_ni)';
            for r=1:R
                br = B(:,r);
                xr_hat = (x_hat-a(r)*br');
                a(r) = ((x-xr_hat)*br)/(br'*br+opt.lambda);
                x_hat = xr_hat+a(r)*br';
            end
            opt.X_hatVals(nz_ni) = x_hat';
            A(i,:) = a;                
        else
            A(i,:) = zeros(1,R);
        end
        As{n} = A;
    end
    time(end+1) = toc;
    opt.As = As;
    X_hat = ktensor(As);
%     fit(end+1) = getFit(X_hat,S);
end
end

function [ X_hat, opt, time ] = updateone_t( X, R, opt, new_idx )
Xsubs = X.subs;
Xvals = X.vals;
As = opt.As;
N = ndims(X);

% main loop
time = [];
% fit = [];
for iter=1:opt.maxiters
    tic
    for n=1:N
        Q_n = prod(opt.AtA(:,:,[1:n-1,n+1:N]),3);
        A = As{n};
        i = new_idx(n);
        nz_ni = opt.sparse_idx{n}{i};
        nnz_ni = length(nz_ni);
        % calculate B
        if nnz_ni ~= 0     
            subs_ni = Xsubs(nz_ni,:);
            B = ones(nnz_ni,R);
            for nn = [1:n-1,n+1:N]
                B = B.*As{nn}(subs_ni(:,nn),:);
            end
            % update
            x = Xvals(nz_ni)';
            P_n = x*B;
            a = A(i,:);
            for r=1:R
                a(r) = (P_n(r)-a*Q_n(:,r))/(Q_n(r,r)+opt.lambda)+a(r)*(Q_n(r,r)/(Q_n(r,r)+opt.lambda));
                if opt.nonneg
                    a(r) = max(a(r), eps);
                end
            end
            A(i,:) = a;                
        else
            A(i,:) = zeros(1,R);
        end
        As{n} = A;
        opt.AtA(:,:,n) = As{n}'*As{n};
    end
    time(end+1) = toc;
    opt.As = As;
    X_hat = ktensor(As);
%     fit(end+1) = getFit(X_hat,S);
end
end



