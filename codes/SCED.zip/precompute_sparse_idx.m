%% Shuo Zhou, Sarah Erfani, and James Bailey,
% "SCED: a general framework for sparse tensor decompositions with
%  constraints and elementwise dynamic learning",
% (C) 2017 Shuo Zhou
% Email: zhous@student.unimelb.edu.au

% To run the code, Tensor Toolbox is required.
% Brett W. Bader, Tamara G. Kolda and others. MATLAB Tensor Toolbox
% Version 2.6, Available online, February 2015.
% URL: http://www.sandia.gov/~tgkolda/TensorToolbox/

%% Precompute sparse index sets for all the row subproblems.
% Takes more memory but can reduce execution time significantly in some cases.
function [ sparseIx ] = precompute_sparse_idx( X )
N = ndims(X);
dims = size(X);
if (isa(X, 'sptensor'))
    fprintf('  Precomputing sparse index sets...\n');
    sparseIx = cell(N,1);
    for n = 1:N
        sparseIx{n} = cell(dims(n),1);
        for jj = 1:dims(n)
            sparseIx{n}{jj} = find(X.subs(:,n) == jj);
        end
    end
end
end

