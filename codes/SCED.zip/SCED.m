%% Shuo Zhou, Sarah Erfani, and James Bailey,
% "SCED: a general framework for sparse tensor decompositions with
%  constraints and elementwise dynamic learning",
% (C) 2017 Shuo Zhou
% Email: zhous@student.unimelb.edu.au

% To run the code, Tensor Toolbox is required.
% Brett W. Bader, Tamara G. Kolda and others. MATLAB Tensor Toolbox
% Version 2.6, Available online, February 2015.
% URL: http://www.sandia.gov/~tgkolda/TensorToolbox/

%% SCED algorithm for static tensors
% input:  X, a sptensor to be decomposed
%         R, rank of data tensor
%         opt, parameters for SCED algorithm:
%            opt.maxiters, maximum number of iterations
%            opt.alpha, weight for zero entries
%                alpha == 0, all zero ensries are Missing Values (MV)
%                alpha == 1, all zero entries are True Observations (TO)
%                alpha in (0, 1), all zero entries are Implicit Information
%                (II)
%            opt.As, initial decomposition, a cell array and each cell is
%                the loading matrix for one mode. Can be none, then the
%                algorithm will be initialized randomly
%            opt.lambda, regularization parameter for L_2 norm
%            opt.nonneg, flag for nonnegativity constraint
%                1, apply nonnegative constraint
%                0, don't apply nonnegative constraint
%            opt.eval, a evaluation set to measure the effectiveness
%                for synthetic data, eval is a ktensor, which is the ground
%                truth decomposition for calculating fitness
%                for real-world data, a sptensor contatins entries in test
%                set will be given to calculate RMSE
%            opt.sparse_idx,
% ouputs: X_hat, a ktensor, the returned decomposition
%         fit, fitness at each iteration
%         time, time cost for each iteration
%         X_hat_vals, a column vector of size nnz(X) which contains all
%             esimation values for non-zero entries in X. This will only be
%             used in MV and II cases

function [ X_hat, fit, time ] = SCED( X, R, opt )
if opt.alpha<0 || opt.alpha>1
    error("Alpha has to be in [0, 1]")
end

if ~isa(X, 'sptensor')
    warning('Converting dense tensor to sparse');
    X = sptensor(X);
end

% checking parameters
if ~isfield(opt, 'sparse_idx')
    opt.sparse_idx = precompute_sparse_idx(X);
end

if ~isfield(opt, 'As')
    dims = size(X);
    opt.As = arrayfun(@(I) (rand(I,R)-.5),dims,'uni',0);
end

if ~isfield(opt, 'lambda')
    opt.lambda = 0.1;
end

if ~isfield(opt, 'nonneg')
    opt.nonneg = 0;
end

% For efficiency consideration, we provide different implementations for
% different cases, while all of them are derived from the same principle
if opt.alpha == 0
    [ X_hat, fit, time ] = SCED_m( X, R, opt );
elseif opt.alpha == 1
    [ X_hat, fit, time ] = SCED_t( X, R, opt );
else
    [ X_hat, fit, time ] = SCED_i( X, R, opt );
end

end

%% decompose for tensor with Implicit Information (II)
function [ X_hat, fit, time ] = SCED_i( X, R, opt )

dims = size(X);
N = length(dims);
As = opt.As;
alpha = opt.alpha;
lambda = opt.lambda;

% indices and values for non-zeros
Xsubs = X.subs;
Xvals = X.vals;

% precompute all AtA for quickly calculating Q
AtA = zeros(R,R,N);
for n = 1:N
    AtA(:,:,n) = As{n}'*As{n};
end

% precompute estimating values for all non-zeros
tmp = ones(nnz(X),R);
for n=1:N
    tmp = tmp.*As{n}(X.subs(:,n),:);
end
X_hat_vals = sum(tmp,2);

% main loop
time = [];
fit = [];
for iter=1:opt.maxiters
    tic
    for n=1:N
        Q_n = prod(AtA(:,:,[1:n-1,n+1:N]),3);
        A = As{n};
        for i=1:dims(n)
            % indices for non-zeros in mode n and row i
            nz_ni = opt.sparse_idx{n}{i};
            nnz_ni = length(nz_ni);
            % calculate B
            if nnz_ni ~= 0
                subs_ni = Xsubs(nz_ni,:);
                B = ones(nnz_ni,R);
                for nn = [1:n-1,n+1:N]
                    B = B.*As{nn}(subs_ni(:,nn),:);
                end
                x = Xvals(nz_ni)';
                a = A(i,:);
                x_hat = X_hat_vals(nz_ni)';
                for r=1:R
                    br = B(:,r);
                    qr = Q_n(:,r);
                    qrr = Q_n(r,r);
                    xr_hat = (x_hat-a(r)*br');
                    a(r) = ((x-(1-alpha)*xr_hat)*br...
                        -alpha*(a*qr-a(r)*qrr))/...
                        ((1-alpha)*(br'*br)+alpha*qrr+lambda);
                    if opt.nonneg == 1
                        a(r) = max(a(r), eps);
                    end
                    x_hat = xr_hat+a(r)*br';
                end
                X_hat_vals(nz_ni) = x_hat';
                A(i,:) = a;
            else
                A(i,:) = zeros(1,R);
            end
        end
        As{n} = A;
        AtA(:,:,n) = As{n}'*As{n};
    end
    time(end+1) = toc;
    X_hat = ktensor(As);
    fit(end+1) = get_fit(X_hat,opt.eval);
end
end

%% decompose for tensor with Missing Value (MV)
function [ X_hat, fit, time, X_hat_vals ] = SCED_m( X, R, opt )

dims = size(X);
N = length(dims);
As = opt.As;
lambda = opt.lambda;

% indices and values for non-zeros
Xsubs = X.subs;
Xvals = X.vals;

% precompute estimating values for all non-zeros
tmp = ones(nnz(X),R);
for n=1:N
    tmp = tmp.*As{n}(X.subs(:,n),:);
end
X_hat_vals = sum(tmp,2);

% main loop
time = [];
fit = [];
for iter=1:opt.maxiters
    tic
    for n=1:N
        A = As{n};
        for i=1:dims(n)
            % indices for non-zeros in mode n and row i
            nz_ni = opt.sparse_idx{n}{i};
            nnz_ni = length(nz_ni);
            % calculate B
            if nnz_ni ~= 0
                subs_ni = Xsubs(nz_ni,:);
                B = ones(nnz_ni,R);
                for nn = [1:n-1,n+1:N]
                    B = B.*As{nn}(subs_ni(:,nn),:);
                end
                x = Xvals(nz_ni)';
                a = A(i,:);
                x_hat = X_hat_vals(nz_ni)';
                for r=1:R
                    br = B(:,r);
                    xr_hat = (x_hat-a(r)*br');
                    a(r) = ((x-xr_hat)*br)/(br'*br+lambda);
                    if opt.nonneg == 1
                        a(r) = max(a(r), eps);
                    end
                    x_hat = xr_hat+a(r)*br';
                end
                X_hat_vals(nz_ni) = x_hat';
                A(i,:) = a;
            else
                A(i,:) = zeros(1,R);
            end
        end
        As{n} = A;
    end
    time(end+1) = toc;
    X_hat = ktensor(As);
    fit(end+1) = get_fit(X_hat,opt.eval);
end
end


%% decompose for tensor with True Observation
function [ X_hat, fit, time ] = SCED_t( X, R, opt )

dims = size(X);
N = length(dims);
As = opt.As;
lambda = opt.lambda;

% indices and values for non-zeros
Xsubs = X.subs;
Xvals = X.vals;

% precompute all AtA for quickly calculating Q
AtA = zeros(R,R,N);
for n = 1:N
    AtA(:,:,n) = As{n}'*As{n};
end

% main loop
time = [];
fit = [];
for iter=1:opt.maxiters
    tic
    for n=1:N
        Q_n = prod(AtA(:,:,[1:n-1,n+1:N]),3);
        A = As{n};
        for i=1:dims(n)
            % indices for non-zeros in mode n and row i
            nz_ni = opt.sparse_idx{n}{i};
            nnz_ni = length(nz_ni);
            % calculate B
            if nnz_ni ~= 0
                subs_ni = Xsubs(nz_ni,:);
                B = ones(nnz_ni,R);
                for nn = [1:n-1,n+1:N]
                    B = B.*As{nn}(subs_ni(:,nn),:);
                end
                % update
                x = Xvals(nz_ni)';
                P_n = x*B;
                a = A(i,:);
                for r=1:R
                    a(r) = (P_n(r)-a*Q_n(:,r))/(Q_n(r,r)+lambda)...
                        +a(r)*(Q_n(r,r)/(Q_n(r,r)+lambda));
                    if opt.nonneg
                        a(r) = max(a(r), eps);
                    end
                end
                A(i,:) = a;
            else
                A(i,:) = zeros(1,R);
            end
        end
        As{n} = A;
        AtA(:,:,n) = As{n}'*As{n};
    end
    time(end+1) = toc;
    X_hat = ktensor(As);
    fit(end+1) = get_fit(X_hat,opt.eval);
end
end



