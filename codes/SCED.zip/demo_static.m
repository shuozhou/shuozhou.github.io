%% Shuo Zhou, Sarah Erfani, and James Bailey,
% "SCED: a general framework for sparse tensor decompositions with
%  constraints and elementwise dynamic learning",
% (C) 2017 Shuo Zhou
% Email: zhous@student.unimelb.edu.au

% To run the code, Tensor Toolbox is required.
% Brett W. Bader, Tamara G. Kolda and others. MATLAB Tensor Toolbox
% Version 2.6, Available online, February 2015.
% URL: http://www.sandia.gov/~tgkolda/TensorToolbox/

%% demo for static case
clc;clear;
close all;

addpath(genpath('.'));

% load('data/syth_t_200.mat');
load('data/syth_m_200.mat');
% load('data/syth_i_200.mat');

R = 20;

% input tensor
X = data.X;
% ground truth
S = data.S;

dims = size(X);
density = nnz(X)/prod(dims);

sced_opt.maxiters = 50;
sced_opt.lambda = 0;
sced_opt.sparse_idx = precompute_sparse_idx(X);
sced_opt.nonneg = 0;
sced_opt.eval = S;

sced_t_opt = sced_opt;
sced_t_opt.alpha = 1;

sced_m_opt = sced_opt;
sced_m_opt.alpha = 0;

sced_i_opt = sced_opt;
sced_i_opt.alpha = density;
 
sced_nn_opt = sced_opt;
sced_nn_opt.alpha = 1;
sced_nn_opt.nonneg = 1;

K = 2; % number of repetitions
for k = 1:K
    k
    init = arrayfun(@(I) (rand(I,R)-.5),dims,'uni',0);  
    nonneg_init = cellfun(@(A) abs(A), init, 'uni', 0);
   
    fprintf('sced_t\n');
    sced_t_opt.As = init;
    [sced_t_X,sced_t_fit(k,:),sced_t_time(k,:)] = SCED(X,R,sced_t_opt);
    
    fprintf('sced_nonneg\n');
    sced_nn_opt.As = nonneg_init;
    [sced_nn_X,sced_nn_fit(k,:),sced_nn_time(k,:)] = SCED(X,R,sced_nn_opt);
    
    fprintf('sced_m\n');
    sced_m_opt.As = init;
    [sced_m_X,sced_m_fit(k,:),sced_m_time(k,:)] = SCED(X,R,sced_m_opt);
   
    fprintf('sced_i\n');
    sced_i_opt.As = init;
    [sced_i_X,sced_i_fit(k,:),sced_i_time(k,:)] = SCED(X,R,sced_i_opt);
end

%% organize and plot results
fit(1,:) = mean(sced_t_fit);
fit(2,:) = mean(sced_nn_fit);
fit(3,:) = mean(sced_m_fit);
fit(4,:) = mean(sced_i_fit);
fig_idx = [1,5,10,15,20,25,30,35,40,45,50];

figure('position', [0, 0, 500, 400])
hold on;
plot(fig_idx,fit(1,fig_idx),'r-o','LineWidth',2,'MarkerSize',10);
plot(fig_idx,fit(2,fig_idx),'m-*','LineWidth',2,'MarkerSize',10);
plot(fig_idx,fit(3,fig_idx),'b-+','LineWidth',2,'MarkerSize',10);
plot(fig_idx,fit(4,fig_idx),'k','LineWidth',2,'MarkerSize',10);
legend('sced-t','sced-nn','sced-m','sced-i','Location','southeast');
xlabel('Number of iterations');
ylabel({'Fitness'});
grid on;
set(gca,'FontSize',14);
axis([0 50 0 1])

time(1,:) = mean(sced_t_time);
time(2,:) = mean(sced_nn_time);
time(3,:) = mean(sced_m_time);
time(4,:) = mean(sced_i_time);
fig_idx = [1,5,10,15,20,25,30,35,40,45,50];
figure('position', [600, 0, 500, 400])
hold on;
plot(fig_idx,time(1,fig_idx),'r-o','LineWidth',2,'MarkerSize',10);
plot(fig_idx,time(2,fig_idx),'m-*','LineWidth',2,'MarkerSize',10);
plot(fig_idx,time(3,fig_idx),'b-+','LineWidth',2,'MarkerSize',10);
plot(fig_idx,time(4,fig_idx),'k','LineWidth',2,'MarkerSize',10);
legend('sced-t','sced-nn','sced-m','sced-i','Location','southeast');
xlabel('Number of iterations');
ylabel({'Running Time'});
grid on;
set(gca,'FontSize',14);
